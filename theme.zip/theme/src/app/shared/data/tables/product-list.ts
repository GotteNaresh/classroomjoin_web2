export class productDB {
    static product = [
        {
            img: "<img src='assets/images/ecommerce/product-table-1.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$10",
            stock: "<div class='font-success'>In Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-2.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$10",
            stock: "<div class='font-danger'>Out of Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-3.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$10",
            stock: "<div class='font-danger'>Out of Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-4.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$20",
            stock: "<div class='font-primary'>Low Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-5.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$30",
            stock: "<div class='font-success'>In Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-6.png'>",
            name: "Brown Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$40",
            stock: "<div class='font-success'>In Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-1.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$10",
            stock: "<div class='font-success'>In Stock</div>",
            date: "2011/4/19"
        },
        {
            img: "<img src='assets/images/ecommerce/product-table-2.png'>",
            name: "Red Lipstick",
            desc: "Interchargebla lens Digital Camera with APS-C-X Trans CMOS Sens",
            amount: "$10",
            stock: "<div class='font-success'>In Stock</div>",
            date: "2011/4/19"
        }
    ]
}
