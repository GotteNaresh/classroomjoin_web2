import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-timeline1',
  templateUrl: './timeline1.component.html',
  styleUrls: ['./timeline1.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class Timeline1Component implements OnInit {

  constructor() { }

  ngOnInit() { }

}
