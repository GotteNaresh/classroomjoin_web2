import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-with-image',
  templateUrl: './login-with-image.component.html',
  styleUrls: ['./login-with-image.component.scss']
})
export class LoginWithImageComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
